export type MenuItem = { id: string; name: string; href: string; exec?: boolean; members?: boolean; sub?: MenuItem[] };   // exec: 집행부·관리자에게만 메뉴에 보임 / members: 로그인한 조합원에게만 메뉴에 보임(바깥 주소·묶음 메뉴용)

// 관리자가 아직 메뉴를 고친 적이 없을 때 쓰는 기본 메뉴
export const DEFAULT_MENU: MenuItem[] = [
  { id: 'notice', name: '공고', href: '/c/notice' },
  { id: 'news', name: '우리소식', href: '/c/news', sub: [
    { id: 'news-all', name: '우리소식', href: '/c/news' },
    { id: 'notice-sub', name: '공고', href: '/c/notice' },
    { id: 'bargaining', name: '임단협뉴스', href: '/c/bargaining' },
    { id: 'letter', name: '위원장 서신', href: '/c/letter' },
    { id: 'newsletter', name: '뉴스레터', href: '/c/newsletter' },
  ] },
  { id: 'agreement', name: '단체협약', href: '/page/agreement' },
  { id: 'community', name: '커뮤니티', href: '/community', sub: [
    { id: 'members', name: '조합원 찾기', href: '/members' },
    { id: 'board', name: '자유게시판', href: '/board' },
    { id: 'chat', name: '그룹챗', href: '/chat' },
  ] },
  { id: 'about', name: '조합소개', href: '/page/about', sub: [
    { id: 'greeting', name: '위원장 인사말', href: '/page/greeting' },
    { id: 'history', name: '조합 역사', href: '/page/history' },
    { id: 'officers', name: '역대 임원진', href: '/page/officers' },
    { id: 'bylaws', name: '규약', href: '/page/bylaws' },
    { id: 'forms', name: '양식', href: '/c/forms' },
  ] },
];
